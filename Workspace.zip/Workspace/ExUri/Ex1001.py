#Leia 2 valores inteiros e armazene-os nas variáveis A e B. 
#Efetue a soma de A e B atribuindo o seu resultado na variável X. 
#Imprima X conforme exemplo apresentado abaixo. 

a = int(input())
b = int(input())
print ("X =", a + b)