# Faça um programa que mostre os números pares entre 1 e 100, inclusive.

for i in range (2, 101, 2):
    print (i)