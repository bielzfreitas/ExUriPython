# Leia dois valores inteiros, no caso para variáveis A e B. A seguir, calcule a soma entre 
#elas e atribua à variável SOMA. A seguir escrever o valor desta variável.

a = int(input())
b = int(input())
soma = a + b
print ("SOMA =", soma)