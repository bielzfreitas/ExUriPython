# Leia dois valores inteiros. A seguir, calcule o produto entre estes dois valores e 
#atribua esta operação à variável PROD. A seguir mostre a variável PROD com mensagem correspondente.

a = int(input())
b = int(input())
prod = a * b

print ("PROD =", prod)