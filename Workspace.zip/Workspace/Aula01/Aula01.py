#Exercícios

#Faça um Programa que peça o raio de um círculo, calcule e mostre sua área.
raio = float(input("Digite o raio do círculo: "))
area = 3.14 * (raio * raio)
print("A área do círculo é:", area)


#Faça um Programa que calcule a área de um quadrado, em seguida mostre o dobro desta área para o usuário.
ladoQuad = float(input("Digite o tamanho do lado do quadrado: "))
areaQuad = ladoQuad * ladoQuad
print("A área do quadrado é:", areaQuad)
dobroAreaQuad = areaQuad * 2
print("O dobro da área do quadrado é:", dobroAreaQuad)


#Faça um Programa que pergunte quanto você ganha por hora e o número de horas trabalhadas no mês. Calcule e mostre o total do seu salário no referido mês.
ganhaHora = float(input("Digite o quanto você ganha por hora: "))
trabalhaMes = float(input("Digite o quanta horas você trabalha no mês: "))
print("Você ganha:", ganhaHora * trabalhaMes, "reais por mês")


#Faça um Programa que peça a temperatura em graus Farenheit, transforme e mostre a temperatura em graus Celsius. C = (5 * (F-32) / 9).
farenheit = float(input("Digite a temperatura em Farenheit: "))
conversao = (5 * (farenheit - 32) / 9)
print("A temperatura em graus Celsius é:", conversao)


#Faça um Programa que peça a temperatura em graus Celsius, transforme e mostre em graus Farenheit.
celsius = float(input("Digite a temperatura em Celsius: "))
conversao = (celsius * 9 / 5 + 32)
print("A temperatura em graus Farenheit é:", conversao)