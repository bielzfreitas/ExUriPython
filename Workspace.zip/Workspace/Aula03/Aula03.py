# em python 2, seria
#for in xrange (2, 10, 2):
#    print(i)

# range é um generator -> não gera uma lista, gera objeto de consulta (entrega sob demanda)
#for in range (3, 10, 2): -> pula de dois em dois
#   print (i)

#for in range (1, 10):
#    if i == 5:
#    print (i)
#        break

#for i in range (1, 11):
#    if i == 5:
#        continue
#    print(i)

#for i in range (1, 11):
#    print (i)
#else:
#    print("Saindo do for. Valor de i: " + str(i))

#for i in range (1,5):
#    if i == 3:
#        break
#    print (i)
#else
#    print ("Saindo do for. Valor de i: " + str(i))

#lista = [4, 5, 5, 3, 1, 7]
#e = int (input("Digite o valor a ser buscado"))
#for i in lista:
#    if i == e:
#        print ("Sim, existe")
#        break
#else:
#    print("Não existe")

#nota = int(input ("Digite uma nota"))
#while nota != -1:
#    if nota >= 6:
#        print ("Você está aprovado")
#    else:
#        print ("Você está reprovado")
#    nota = int(input ("Digite mais uma nota"))
#else:
#    print ("Até mais")

# % -> Quociente

# Fazer exercícios do URI -> 1001 a 1099






# -> Exemplos

# 1. Faça um programa que mostre os números pares entre 1 e 100, inclusive.

for i in range (2, 101, 2):
    print (i)



# 2. Leia 5 valores Inteiros. A seguir mostre quantos valores digitados foram pares, quantos valores 
#digitados foram ímpares, quantos valores digitados foram positivos e quantos valores digitados foram negativos.

#n1 = int(input ())
#lista = []
pares = 0
impares = 0
positivos = 0
negativos = 0
for i in range (1,6):
    v = int (input())
    if v % 2 == 0:
        pares += 1
    else:
        impares += 1

    if v > 0:
        positivos += 1
    elif v < 0:
        negativos += 1

print (str(pares) + ' valor(es) par(es) ')
print (str(impares) + ' valor(es) impar(es) ')
print (str(positivos) + ' valor(es) positivo(s) ')
print (str(negativos) + ' valor(es) negativo(s) ')




# 3. Leia um valor inteiro X. Em seguida apresente os 6 valores ímpares consecutivos a partir de X, 
#um valor por linha, inclusive o X ser for o caso.

x = int (input())
for i in range (x if x % 2 == 1 else x + 1, x + 12, 2):
    print (i)


# 4. Você tem em mãos dois cabos circulares de energia. O primeiro cabo tem raio R1 e o segundo raio R2. 
#Você precisa comprar um conduite circular (veja a imagem abaixo que ilustra um conduite) de maneira a 
#passar os dois cabos por dentro dele:
#Qual o menor raio do conduite que você deve comprar? Em outras palavras, dado dois círculos, 
#qual o raio do menor círculo que possa englobar ambos os dois?

n = int (input())
for i in range (1, n + 1):
    a, b = input().split()  # -> quebra a entrada em pequenos tokens
    print (int(a) + int(b))