# 1. Faça um programa que leia 6 valores. Estes valores serão somente negativos ou positivos 
#(desconsidere os valores nulos). A seguir, mostre a quantidade de valores positivos digitados.

positivos = 0
negativos = 0

for i in range (1,7):
    n = float(input())
    if n > 0:
        positivos += 1
    elif n < 0:
        negativos += 1

print(str(positivos) + ' valores positivos')