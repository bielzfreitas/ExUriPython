# 2. Leia um valor inteiro N. Apresente o quadrado de cada um dos valores pares,
#de 1 até N, inclusive N, se for o caso.

n = int (input())
for i in range (2, n + 1, 2):
    print (str(i) + '^2 =', i * i )
