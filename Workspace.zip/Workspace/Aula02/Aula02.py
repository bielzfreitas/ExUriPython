#1. Escreva um programa que lê três valores inteiros e os exibe em ordem crescente.
lista = [(3,2,1)]
for n1,n2,n3 in lista:
    if(n1 > n2 and n1 > n3):
        if(n3 > n2):
            print(n3,n2,n1)
        else:
            print(n3,n2,n1)

#2. Escreva um programa que lê a idade de uma pessoa e decide se ela pode ou não tirar sua carta de motorista, de acordo com a legislação brasileira.
idade = int (input ("Digite sua idade"))
if idade >= 18:
    print ("Pode tirar habilitação")
else:
    print ("Não pode tirar habilitação")

#3. Resolva o exercício do link a seguir de duas formas diferentes. Na primeira, use f-string. na segunda, use o método format da classe string.
#A fórmula para calcular a área de uma circunferência é: area = π . raio2. Considerando para este problema que π = 3.14159:
#Efetue o cálculo da área, elevando o valor de raio ao quadrado e multiplicando por π.
#A entrada contém um valor de ponto flutuante (dupla precisão), no caso, a variável raio.
#Apresentar a mensagem "A=" seguido pelo valor da variável area, conforme exemplo abaixo, com 4 casas após o ponto decimal. Utilize variáveis de dupla precisão (double). 
#Como todos os problemas, não esqueça de imprimir o fim de linha após o resultado, caso contrário, você receberá "Presentation Error".

#f-string
r = float (input ("Digite o raio: "))
n = 3.14159
a = n * r * r
print (f'Valor da area: {a:^10}')

#format
r = float (input ("Digite o raio: "))
n = 3.14159
a = n * r * r
print ("Área é: {}".format(a))

